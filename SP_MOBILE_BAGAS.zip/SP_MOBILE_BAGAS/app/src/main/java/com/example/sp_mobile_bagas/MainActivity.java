package com.example.sp_mobile_bagas;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText display;
    private StringBuilder currentInput;
    private String operator;
    private double operand1;
    private boolean isNewOperation;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        display = findViewById(R.id.display);
        currentInput = new StringBuilder();
        isNewOperation = true;

        setupButtonClick(R.id.button0, "0");
        setupButtonClick(R.id.button1, "1");
        setupButtonClick(R.id.button2, "2");
        setupButtonClick(R.id.button3, "3");
        setupButtonClick(R.id.button4, "4");
        setupButtonClick(R.id.button5, "5");
        setupButtonClick(R.id.button6, "6");
        setupButtonClick(R.id.button7, "7");
        setupButtonClick(R.id.button8, "8");
        setupButtonClick(R.id.button9, "9");
        setupButtonClick(R.id.buttonDot, ".");

        findViewById(R.id.buttontambah).setOnClickListener(v -> setOperator("+"));
        findViewById(R.id.buttonkurang).setOnClickListener(v -> setOperator("-"));
        findViewById(R.id.buttonkali).setOnClickListener(v -> setOperator("*"));
        findViewById(R.id.buttonbagi).setOnClickListener(v -> setOperator("/"));
        findViewById(R.id.buttonsamadengan).setOnClickListener(v -> calculateResult());
        findViewById(R.id.buttonhapus).setOnClickListener(v -> clearDisplay());
    }

    private void setupButtonClick(int buttonId, String value) {
        Button button = findViewById(buttonId);
        button.setOnClickListener(v -> {
            if (isNewOperation) {
                currentInput.setLength(0);
                isNewOperation = false;
            }
            currentInput.append(value);
            display.setText(currentInput.toString());
        });
    }

    private void setOperator(String op) {
        operand1 = Double.parseDouble(currentInput.toString());
        currentInput.setLength(0);
        operator = op;
        isNewOperation = false;
    }

    private void calculateResult() {
        double operand2 = Double.parseDouble(currentInput.toString());
        double result = 0;
        switch (operator) {
            case "+":
                result = operand1 + operand2;
                break;
            case "-":
                result = operand1 - operand2;
                break;
            case "*":
                result = operand1 * operand2;
                break;
            case "/":
                result = operand1 / operand2;
                break;
        }
        display.setText(String.valueOf(result));
        currentInput.setLength(0);
        currentInput.append(result);
        isNewOperation = true;
    }

    private void clearDisplay() {
        currentInput.setLength(0);
        display.setText("");
        isNewOperation = true;
    }
}